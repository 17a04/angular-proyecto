import { Personaje1Module } from '../personaje1-module';
export interface ICaracter {
  id?: string;
  name: string;
  tiempo: number;
  nivel: number;
  vistas: number;
}
